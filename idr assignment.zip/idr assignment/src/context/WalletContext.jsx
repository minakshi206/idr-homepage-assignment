import { createContext, useContext, useState } from 'react';

const WalletContext = createContext(undefined);

export const WalletProvider = ({ children }) => {
  const [balance, setBalance] = useState(5000);
  const [transactions, setTransactions] = useState([
    {
      id: '1',
      type: 'add',
      amount: 2000,
      date: new Date(Date.now() - 86400000 * 2),
      status: 'success',
    },
    {
      id: '2',
      type: 'send',
      amount: 500,
      date: new Date(Date.now() - 86400000),
      status: 'success',
      recipient: '9876543210',
    },
    {
      id: '3',
      type: 'add',
      amount: 3500,
      date: new Date(Date.now() - 3600000 * 5),
      status: 'success',
    },
  ]);

  const addMoney = (amount) => {
    setBalance((prev) => prev + amount);
    const newTransaction = {
      id: Date.now().toString(),
      type: 'add',
      amount,
      date: new Date(),
      status: 'success',
    };
    setTransactions((prev) => [newTransaction, ...prev]);
  };

  const sendMoney = (amount, recipient) => {
    if (amount > balance) {
      return false;
    }
    setBalance((prev) => prev - amount);
    const newTransaction = {
      id: Date.now().toString(),
      type: 'send',
      amount,
      date: new Date(),
      status: 'success',
      recipient,
    };
    setTransactions((prev) => [newTransaction, ...prev]);
    return true;
  };

  return (
    <WalletContext.Provider value={{ balance, transactions, addMoney, sendMoney }}>
      {children}
    </WalletContext.Provider>
  );
};

export const useWallet = () => {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
};
