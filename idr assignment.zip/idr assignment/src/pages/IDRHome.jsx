import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import logoIcon from '@/assets/idr-logo-icon.png';

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i = 0) => ({
    opacity: 1, y: 0,
    transition: { delay: i * 0.1, duration: 0.6, ease: 'easeOut' }
  })
};

const IDRHome = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [formSubmitted, setFormSubmitted] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = () => setMobileMenuOpen(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setFormSubmitted(true);
    setFormData({ name: '', email: '', message: '' });
    setTimeout(() => setFormSubmitted(false), 3000);
  };

  const navLinks = [
    { label: 'About', href: '#about' },
    { label: 'Services', href: '#services' },
    { label: 'Community', href: '#community' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <>
      {/* ===== STICKY NAVBAR ===== */}
      <header>
        <nav className={`idr-nav ${scrolled ? 'scrolled' : ''}`} role="navigation" aria-label="Main navigation">
          <div className="nav-container">
            <a href="#hero" className="nav-logo" aria-label="IDR Home">
              <img src={logoIcon} alt="IDR Logo" width="40" height="40" />
              <span>IDR</span>
            </a>

            <div className="nav-links">
              {navLinks.map((link) => (
                <a key={link.href} href={link.href}>{link.label}</a>
              ))}
              <a href="#contact" className="nav-cta">Register Interest</a>
            </div>

            <button
              className="mobile-menu-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Toggle menu"
              aria-expanded={mobileMenuOpen}
            >
              <span></span><span></span><span></span>
            </button>
          </div>
        </nav>

        <div className={`mobile-nav ${mobileMenuOpen ? 'open' : ''}`}>
          {navLinks.map((link) => (
            <a key={link.href} href={link.href} onClick={handleNavClick}>{link.label}</a>
          ))}
          <a href="#contact" className="nav-cta" onClick={handleNavClick} style={{ textAlign: 'center' }}>
            Register Interest
          </a>
        </div>
      </header>

      <main>
        {/* ===== HERO SECTION ===== */}
        <section id="hero" className="hero-section" aria-label="Hero">
          <div className="hero-grid-pattern"></div>
          <div className="hero-container">
            <motion.div className="hero-content" initial="hidden" animate="visible" variants={fadeUp}>
              <motion.div className="hero-badge" variants={fadeUp} custom={0}>
                <span></span> Industry-Led Institute
              </motion.div>

              <motion.h1 variants={fadeUp} custom={1}>
                Advancing the Future of <span className="highlight">Digital Risk</span>
              </motion.h1>

              <motion.p variants={fadeUp} custom={2}>
                IDR trains and deploys digital risk practitioners, combining rigorous academic
                collaboration with hands-on industry practice to build resilient organisations.
              </motion.p>

              <motion.div className="hero-buttons" variants={fadeUp} custom={3}>
                <a href="#services" className="btn-primary">
                  Explore Programs →
                </a>
                <a href="#contact" className="btn-secondary">
                  Hire Talent
                </a>
              </motion.div>

              <motion.div className="hero-stats" variants={fadeUp} custom={4}>
                <div className="hero-stat">
                  <div className="stat-value">50<span className="orange">+</span></div>
                  <div className="stat-label">Industry Partners</div>
                </div>
                <div className="hero-stat">
                  <div className="stat-value">1,200<span className="orange">+</span></div>
                  <div className="stat-label">Practitioners Trained</div>
                </div>
                <div className="hero-stat">
                  <div className="stat-value">98<span className="orange">%</span></div>
                  <div className="stat-label">Deployment Rate</div>
                </div>
              </motion.div>
            </motion.div>

            <motion.div
              className="hero-visual"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3, duration: 0.8, ease: 'easeOut' }}
            >
              <div className="hero-cube-container">
                <img src={logoIcon} alt="IDR Cube Logo" className="hero-cube-img" />
              </div>
            </motion.div>
          </div>
        </section>

        {/* ===== ABOUT SECTION ===== */}
        <section id="about" className="section about-section" aria-label="About IDR">
          <div className="section-container">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-100px' }} variants={fadeUp}>
              <div className="section-label">About Us</div>
              <h2 className="section-title">Who We Are</h2>
              <p className="section-subtitle">
                Bridging academia and industry to build the next generation of digital risk professionals.
              </p>
            </motion.div>

            <div className="about-grid">
              <motion.div className="about-text" initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-100px' }} variants={fadeUp} custom={1}>
                <p>
                  The <strong>Institute of Digital Risk (IDR)</strong> is an industry-led training and deployment
                  institute for digital, cyber, and technology risk roles. We operate at the intersection
                  of academic rigour and practical application, preparing professionals for regulated,
                  high-consequence environments.
                </p>
                <p>
                  Through our <strong>UK university partnerships</strong>, we ensure that every programme is grounded
                  in the latest research while being directly applicable to real-world challenges across
                  financial services, critical infrastructure, and beyond. Our unique model combines structured
                  training with live project deployment, ensuring graduates are job-ready from day one.
                </p>
              </motion.div>

              <motion.div className="about-features" initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-100px' }} variants={fadeUp} custom={2}>
                <div className="about-feature-card">
                  <div className="about-feature-icon">🎓</div>
                  <div>
                    <h4>University Partnerships</h4>
                    <p>Collaborating with leading UK universities to deliver accredited, research-backed programmes.</p>
                  </div>
                </div>
                <div className="about-feature-card">
                  <div className="about-feature-icon">🏢</div>
                  <div>
                    <h4>Industry-Led Curriculum</h4>
                    <p>Training designed by practitioners, for practitioners, reflecting real regulatory demands.</p>
                  </div>
                </div>
                <div className="about-feature-card">
                  <div className="about-feature-icon">🚀</div>
                  <div>
                    <h4>Deployment Ready</h4>
                    <p>Graduates transition directly into high-impact roles through our placement pipeline.</p>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* ===== SERVICES SECTION ===== */}
        <section id="services" className="section services-section" aria-label="Service Model">
          <div className="section-container">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-100px' }} variants={fadeUp}>
              <div className="section-label">Service Model</div>
              <h2 className="section-title" style={{ color: 'white' }}>What We Do</h2>
              <p className="section-subtitle">
                Three integrated pillars that drive our mission — from training to deployment.
              </p>
            </motion.div>

            <div className="services-grid">
              {[
                {
                  icon: '📚',
                  title: 'Academy',
                  desc: 'Intensive training programmes and bootcamps designed for students and working professionals. Our curriculum covers digital risk, cyber security, AI governance, and regulatory frameworks.'
                },
                {
                  icon: '💡',
                  title: 'Innovation & Incubation',
                  desc: 'Developing proprietary intellectual property, future risk models, and AI governance frameworks. We incubate cutting-edge solutions for emerging digital threats.'
                },
                {
                  icon: '🛡️',
                  title: 'Advisory Services',
                  desc: 'Helping organisations implement industry-standard frameworks including NIST, ISO 27001, and NIS2. Expert guidance for regulatory compliance and risk management.'
                }
              ].map((service, i) => (
                <motion.div
                  key={service.title}
                  className="service-card"
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true, margin: '-80px' }}
                  variants={fadeUp}
                  custom={i + 1}
                >
                  <div className="service-icon">{service.icon}</div>
                  <h3>{service.title}</h3>
                  <p>{service.desc}</p>
                </motion.div>
              ))}
            </div>

            {/* Pipeline */}
            <motion.div className="pipeline-section" initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-80px' }} variants={fadeUp} custom={1}>
              <h3>Our Pipeline</h3>
              <p>The end-to-end journey from learning to impact.</p>
              <div className="pipeline">
                {['Train', 'Hire', 'Innovate', 'Deploy'].map((step, i) => (
                  <div className="pipeline-step" key={step}>
                    <div className="step-content">
                      <div className="step-number">{i + 1}</div>
                      <div className="step-label">{step}</div>
                    </div>
                    {i < 3 && <div className="pipeline-arrow">→</div>}
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {/* ===== COMMUNITY SECTION ===== */}
        <section id="community" className="section community-section" aria-label="Community">
          <div className="section-container">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-100px' }} variants={fadeUp}>
              <div className="section-label">Community</div>
              <h2 className="section-title">Who We Serve</h2>
              <p className="section-subtitle">
                A growing community of risk professionals building resilience across industries.
              </p>
            </motion.div>

            <div className="community-grid">
              <motion.div className="community-text" initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-100px' }} variants={fadeUp} custom={1}>
                <p>
                  Our community brings together <strong>students, early-career professionals, and seasoned practitioners</strong> across
                  financial services and critical infrastructure sectors. Whether you're seeking to upskill
                  in digital and cyber risk, transition into a specialist role, or stay ahead of evolving
                  regulatory landscapes — IDR provides the pathway.
                </p>
                <div className="community-tags">
                  {['Financial Services', 'Critical Infrastructure', 'Cyber Security', 'AI Governance', 'Regulatory Compliance', 'Technology Risk', 'Data Protection'].map(tag => (
                    <span key={tag} className="community-tag">{tag}</span>
                  ))}
                </div>
              </motion.div>

              <motion.div className="community-cards" initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-100px' }} variants={fadeUp} custom={2}>
                {[
                  { icon: '🎓', title: 'Students', desc: 'Kickstart your career in digital risk with hands-on training.' },
                  { icon: '💼', title: 'Early-Career Professionals', desc: 'Accelerate your growth with specialist certifications.' },
                  { icon: '🔬', title: 'Practitioners', desc: 'Stay ahead with advanced frameworks and emerging risk models.' },
                  { icon: '🏛️', title: 'Organisations', desc: 'Access a pipeline of deployment-ready risk talent.' },
                ].map(card => (
                  <div key={card.title} className="community-card">
                    <div className="community-card-icon">{card.icon}</div>
                    <div>
                      <h4>{card.title}</h4>
                      <p>{card.desc}</p>
                    </div>
                  </div>
                ))}
              </motion.div>
            </div>
          </div>
        </section>

        {/* ===== CONTACT SECTION ===== */}
        <section id="contact" className="section contact-section" aria-label="Contact">
          <div className="section-container">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-100px' }} variants={fadeUp}>
              <div className="section-label">Get In Touch</div>
              <h2 className="section-title">Register Your Interest</h2>
              <p className="section-subtitle">
                Ready to advance your career in digital risk? Let us know how we can help.
              </p>
            </motion.div>

            <div className="contact-grid">
              <motion.div className="contact-info" initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-100px' }} variants={fadeUp} custom={1}>
                <h3>Let's Start a Conversation</h3>
                <p>
                  Whether you're a student, professional, or organisation looking to build digital risk
                  capability — we'd love to hear from you. Fill out the form or reach out directly.
                </p>
                <div className="contact-details">
                  <div className="contact-detail">
                    <div className="contact-detail-icon">📧</div>
                    <span>hello@idr-institute.org</span>
                  </div>
                  <div className="contact-detail">
                    <div className="contact-detail-icon">📍</div>
                    <span>London, United Kingdom</span>
                  </div>
                  <div className="contact-detail">
                    <div className="contact-detail-icon">🌐</div>
                    <span>www.idr-institute.org</span>
                  </div>
                </div>
              </motion.div>

              <motion.div initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-100px' }} variants={fadeUp} custom={2}>
                <form className="contact-form" onSubmit={handleSubmit}>
                  <div className="form-group">
                    <label htmlFor="name">Full Name</label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      placeholder="Your full name"
                      value={formData.name}
                      onChange={e => setFormData({ ...formData, name: e.target.value })}
                      required
                    />
                  </div>
                  <div className="form-group">
                    <label htmlFor="email">Email Address</label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      placeholder="you@example.com"
                      value={formData.email}
                      onChange={e => setFormData({ ...formData, email: e.target.value })}
                      required
                    />
                  </div>
                  <div className="form-group">
                    <label htmlFor="message">Message</label>
                    <textarea
                      id="message"
                      name="message"
                      placeholder="Tell us about your interest..."
                      value={formData.message}
                      onChange={e => setFormData({ ...formData, message: e.target.value })}
                      required
                    ></textarea>
                  </div>
                  <button type="submit" className="form-submit">
                    {formSubmitted ? '✓ Submitted Successfully!' : 'Register Interest'}
                  </button>
                </form>
              </motion.div>
            </div>
          </div>
        </section>
      </main>

      {/* ===== FOOTER ===== */}
      <footer className="idr-footer" role="contentinfo">
        <div className="footer-container">
          <div className="footer-grid">
            <div className="footer-brand">
              <div className="footer-logo">
                <img src={logoIcon} alt="IDR" width="32" height="32" />
                <span>Institute of Digital Risk</span>
              </div>
              <p>
                An industry-led training and deployment institute focused on digital, cyber, and AI risk,
                bridging academic insight with real-world practice.
              </p>
            </div>
            <div className="footer-col">
              <h4>Programs</h4>
              <a href="#services">Academy</a>
              <a href="#services">Innovation Lab</a>
              <a href="#services">Advisory</a>
              <a href="#services">Bootcamps</a>
            </div>
            <div className="footer-col">
              <h4>Company</h4>
              <a href="#about">About IDR</a>
              <a href="#community">Community</a>
              <a href="#contact">Careers</a>
              <a href="#contact">Contact</a>
            </div>
            <div className="footer-col">
              <h4>Resources</h4>
              <a href="#services">NIST Framework</a>
              <a href="#services">ISO 27001</a>
              <a href="#services">NIS2 Guide</a>
              <a href="#community">Blog</a>
            </div>
          </div>
          <div className="footer-bottom">
            <span>© 2026 Institute of Digital Risk. All rights reserved.</span>
            <span>London, UK</span>
          </div>
        </div>
      </footer>
    </>
  );
};

export default IDRHome;
