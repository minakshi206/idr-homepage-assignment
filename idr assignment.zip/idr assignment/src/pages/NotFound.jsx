import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import { Box, Typography, Button, Container } from "@mui/material";
import { Home } from "@mui/icons-material";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <Box
      sx={{
        display: 'flex',
        minHeight: '100vh',
        alignItems: 'center',
        justifyContent: 'center',
        bgcolor: '#f1f5f9',
      }}
    >
      <Container maxWidth="sm">
        <Box sx={{ textAlign: 'center' }}>
          <Typography
            variant="h1"
            sx={{ fontWeight: 700, mb: 2, color: 'var(--primary-color)' }}
          >
            404
          </Typography>
          <Typography
            variant="h5"
            sx={{ mb: 3, color: 'var(--muted-color)' }}
          >
            Oops! Page not found
          </Typography>
          <Button
            variant="contained"
            href="/"
            startIcon={<Home />}
            sx={{
              background: 'var(--gradient-primary)',
              px: 4,
              py: 1.5,
              borderRadius: 2,
              fontWeight: 600,
            }}
          >
            Return to Home
          </Button>
        </Box>
      </Container>
    </Box>
  );
};

export default NotFound;
