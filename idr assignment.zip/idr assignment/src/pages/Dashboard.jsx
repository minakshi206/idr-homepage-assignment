import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Card, CardContent, Container, Box, Typography, Grid, IconButton, Chip } from '@mui/material';
import {
  AccountBalanceWallet,
  AddCard,
  Send,
  History,
  TrendingUp,
  ArrowUpward,
  ArrowDownward,
  ArrowForward,
  Visibility,
  VisibilityOff,
} from '@mui/icons-material';
import { useState } from 'react';
import Navbar from '@/components/Navbar';
import { useWallet } from '@/contexts/WalletContext';

const Dashboard = () => {
  const navigate = useNavigate();
  const { balance, transactions } = useWallet();
  const [showBalance, setShowBalance] = useState(true);

  const actionCards = [
    {
      icon: <AddCard sx={{ fontSize: 32 }} />,
      title: 'Add Money',
      description: 'Top up your wallet instantly',
      path: '/add-money',
      gradient: 'linear-gradient(135deg, #22c55e 0%, #16a34a 100%)',
    },
    {
      icon: <Send sx={{ fontSize: 32 }} />,
      title: 'Send Money',
      description: 'Transfer to anyone, anywhere',
      path: '/send-money',
      gradient: 'linear-gradient(135deg, #1e3a5f 0%, #2d5a87 100%)',
    },
    {
      icon: <History sx={{ fontSize: 32 }} />,
      title: 'History',
      description: 'View all your transactions',
      path: '/history',
      gradient: 'linear-gradient(135deg, #f97316 0%, #ea580c 100%)',
    },
  ];

  const recentTransactions = transactions.slice(0, 4);

  const totalAdded = transactions
    .filter((t) => t.type === 'add')
    .reduce((sum, t) => sum + t.amount, 0);
  const totalSent = transactions
    .filter((t) => t.type === 'send')
    .reduce((sum, t) => sum + t.amount, 0);

  return (
    <Box
      sx={{
        minHeight: '100vh',
        background: 'linear-gradient(135deg, #f8fafc 0%, #e2e8f0 50%, #f1f5f9 100%)',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* Animated Background Elements */}
      <Box sx={{ position: 'absolute', inset: 0, overflow: 'hidden', pointerEvents: 'none' }}>
        <motion.div
          animate={{ x: [0, 30, 0], y: [0, -30, 0] }}
          transition={{ duration: 20, repeat: Infinity, ease: 'easeInOut' }}
          style={{
            position: 'absolute',
            top: '10%',
            right: '10%',
            width: 300,
            height: 300,
            borderRadius: '50%',
            background: 'radial-gradient(circle, rgba(249,115,22,0.15) 0%, transparent 70%)',
            filter: 'blur(40px)',
          }}
        />
        <motion.div
          animate={{ x: [0, -20, 0], y: [0, 20, 0] }}
          transition={{ duration: 15, repeat: Infinity, ease: 'easeInOut' }}
          style={{
            position: 'absolute',
            bottom: '20%',
            left: '5%',
            width: 250,
            height: 250,
            borderRadius: '50%',
            background: 'radial-gradient(circle, rgba(30,58,95,0.12) 0%, transparent 70%)',
            filter: 'blur(40px)',
          }}
        />
      </Box>

      <Navbar />

      <Container maxWidth="lg" sx={{ py: 4, position: 'relative', zIndex: 1 }}>
        {/* Welcome Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Box sx={{ mb: 4 }}>
            <Typography
              variant="h4"
              sx={{
                fontWeight: 800,
                color: 'var(--primary-color)',
                mb: 0.5,
              }}
            >
              Welcome back! 👋
            </Typography>
            <Typography sx={{ color: 'var(--muted-color)', fontSize: '1rem' }}>
              Here's what's happening with your wallet today
            </Typography>
          </Box>
        </motion.div>

        <Grid container spacing={3}>
          {/* Main Wallet Card */}
          <Grid item xs={12} lg={8}>
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1, duration: 0.5 }}
            >
              <Card
                elevation={0}
                sx={{
                  borderRadius: 4,
                  overflow: 'hidden',
                  background: 'linear-gradient(135deg, #1e3a5f 0%, #2d5a87 50%, #3d6a97 100%)',
                  color: 'white',
                  position: 'relative',
                  boxShadow: '0 25px 50px -12px rgba(30, 58, 95, 0.4)',
                }}
              >
                {/* Card Pattern */}
                <Box
                  sx={{
                    position: 'absolute',
                    inset: 0,
                    opacity: 0.1,
                    background: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
                  }}
                />
                
                <CardContent sx={{ p: 4, position: 'relative' }}>
                  <Box sx={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', mb: 4 }}>
                    <Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
                        <Typography sx={{ color: 'rgba(255,255,255,0.7)', fontSize: '0.875rem', fontWeight: 500 }}>
                          Total Balance
                        </Typography>
                        <IconButton
                          size="small"
                          onClick={() => setShowBalance(!showBalance)}
                          sx={{ color: 'rgba(255,255,255,0.7)', p: 0.5 }}
                        >
                          {showBalance ? <Visibility sx={{ fontSize: 18 }} /> : <VisibilityOff sx={{ fontSize: 18 }} />}
                        </IconButton>
                      </Box>
                      <motion.div
                        initial={{ scale: 0.9 }}
                        animate={{ scale: 1 }}
                        transition={{ type: 'spring', stiffness: 200 }}
                      >
                        <Typography variant="h2" sx={{ fontWeight: 800, letterSpacing: '-0.02em' }}>
                          {showBalance ? `₹${balance.toLocaleString('en-IN')}` : '₹••••••'}
                        </Typography>
                      </motion.div>
                    </Box>
                    <motion.div
                      animate={{ rotate: [0, 10, -10, 0] }}
                      transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                    >
                      <Box
                        sx={{
                          width: 64,
                          height: 64,
                          borderRadius: 3,
                          background: 'rgba(255,255,255,0.2)',
                          backdropFilter: 'blur(10px)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          border: '1px solid rgba(255,255,255,0.3)',
                        }}
                      >
                        <AccountBalanceWallet sx={{ fontSize: 36 }} />
                      </Box>
                    </motion.div>
                  </Box>

                  <Grid container spacing={2}>
                    <Grid item xs={6}>
                      <motion.div whileHover={{ scale: 1.02 }} transition={{ type: 'spring', stiffness: 400 }}>
                        <Box
                          sx={{
                            bgcolor: 'rgba(255,255,255,0.15)',
                            backdropFilter: 'blur(10px)',
                            borderRadius: 3,
                            p: 2.5,
                            border: '1px solid rgba(255,255,255,0.2)',
                          }}
                        >
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1 }}>
                            <Box
                              sx={{
                                width: 32,
                                height: 32,
                                borderRadius: 2,
                                bgcolor: 'rgba(74, 222, 128, 0.3)',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                              }}
                            >
                              <ArrowDownward sx={{ fontSize: 18, color: '#4ade80' }} />
                            </Box>
                            <Typography sx={{ color: 'rgba(255,255,255,0.8)', fontSize: '0.875rem', fontWeight: 500 }}>
                              Money Added
                            </Typography>
                          </Box>
                          <Typography variant="h5" sx={{ fontWeight: 700 }}>
                            ₹{totalAdded.toLocaleString('en-IN')}
                          </Typography>
                        </Box>
                      </motion.div>
                    </Grid>
                    <Grid item xs={6}>
                      <motion.div whileHover={{ scale: 1.02 }} transition={{ type: 'spring', stiffness: 400 }}>
                        <Box
                          sx={{
                            bgcolor: 'rgba(255,255,255,0.15)',
                            backdropFilter: 'blur(10px)',
                            borderRadius: 3,
                            p: 2.5,
                            border: '1px solid rgba(255,255,255,0.2)',
                          }}
                        >
                          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1 }}>
                            <Box
                              sx={{
                                width: 32,
                                height: 32,
                                borderRadius: 2,
                                bgcolor: 'rgba(248, 113, 113, 0.3)',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                              }}
                            >
                              <ArrowUpward sx={{ fontSize: 18, color: '#f87171' }} />
                            </Box>
                            <Typography sx={{ color: 'rgba(255,255,255,0.8)', fontSize: '0.875rem', fontWeight: 500 }}>
                              Money Sent
                            </Typography>
                          </Box>
                          <Typography variant="h5" sx={{ fontWeight: 700 }}>
                            ₹{totalSent.toLocaleString('en-IN')}
                          </Typography>
                        </Box>
                      </motion.div>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </motion.div>
          </Grid>

          {/* Stats Card */}
          <Grid item xs={12} lg={4}>
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              style={{ height: '100%' }}
            >
              <Card
                elevation={0}
                sx={{
                  borderRadius: 4,
                  height: '100%',
                  background: 'rgba(255, 255, 255, 0.8)',
                  backdropFilter: 'blur(20px)',
                  border: '1px solid rgba(255, 255, 255, 0.5)',
                  boxShadow: '0 10px 40px -10px rgba(0,0,0,0.1)',
                }}
              >
                <CardContent sx={{ p: 3, height: '100%', display: 'flex', flexDirection: 'column' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
                    <Box
                      sx={{
                        width: 48,
                        height: 48,
                        borderRadius: 3,
                        background: 'linear-gradient(135deg, #f97316 0%, #ea580c 100%)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        boxShadow: '0 8px 20px -4px rgba(249, 115, 22, 0.4)',
                      }}
                    >
                      <TrendingUp sx={{ color: 'white', fontSize: 24 }} />
                    </Box>
                    <Box>
                      <Typography sx={{ fontSize: '0.875rem', color: 'var(--muted-color)', fontWeight: 500 }}>
                        Activity Overview
                      </Typography>
                      <Typography variant="h5" sx={{ fontWeight: 800, color: 'var(--primary-color)' }}>
                        {transactions.length} Transactions
                      </Typography>
                    </Box>
                  </Box>

                  <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 2 }}>
                    <Box
                      sx={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        p: 2,
                        borderRadius: 2,
                        bgcolor: 'rgba(34, 197, 94, 0.1)',
                        border: '1px solid rgba(34, 197, 94, 0.2)',
                      }}
                    >
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                        <AddCard sx={{ color: 'var(--success-color)', fontSize: 20 }} />
                        <Typography sx={{ fontWeight: 500, color: '#333' }}>Added</Typography>
                      </Box>
                      <Chip
                        label={transactions.filter((t) => t.type === 'add').length}
                        size="small"
                        sx={{
                          bgcolor: 'var(--success-color)',
                          color: 'white',
                          fontWeight: 700,
                        }}
                      />
                    </Box>
                    <Box
                      sx={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        p: 2,
                        borderRadius: 2,
                        bgcolor: 'rgba(30, 58, 95, 0.08)',
                        border: '1px solid rgba(30, 58, 95, 0.15)',
                      }}
                    >
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                        <Send sx={{ color: 'var(--primary-color)', fontSize: 20 }} />
                        <Typography sx={{ fontWeight: 500, color: '#333' }}>Sent</Typography>
                      </Box>
                      <Chip
                        label={transactions.filter((t) => t.type === 'send').length}
                        size="small"
                        sx={{
                          bgcolor: 'var(--primary-color)',
                          color: 'white',
                          fontWeight: 700,
                        }}
                      />
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            </motion.div>
          </Grid>
        </Grid>

        {/* Quick Actions */}
        <Box sx={{ mt: 4 }}>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.5 }}
          >
            <Typography variant="h6" sx={{ fontWeight: 700, mb: 3, color: 'var(--primary-color)' }}>
              Quick Actions
            </Typography>
          </motion.div>

          <Grid container spacing={3}>
            {actionCards.map((card, index) => (
              <Grid item xs={12} sm={6} md={4} key={index}>
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + index * 0.1, duration: 0.5 }}
                  whileHover={{ y: -8, transition: { duration: 0.2 } }}
                  onClick={() => navigate(card.path)}
                  style={{ cursor: 'pointer' }}
                >
                  <Card
                    elevation={0}
                    sx={{
                      borderRadius: 4,
                      background: card.gradient,
                      color: 'white',
                      overflow: 'hidden',
                      position: 'relative',
                      boxShadow: '0 15px 35px -10px rgba(0,0,0,0.2)',
                      transition: 'box-shadow 0.3s ease',
                      '&:hover': {
                        boxShadow: '0 25px 50px -12px rgba(0,0,0,0.3)',
                      },
                    }}
                  >
                    {/* Card Decoration */}
                    <Box
                      sx={{
                        position: 'absolute',
                        top: -30,
                        right: -30,
                        width: 120,
                        height: 120,
                        borderRadius: '50%',
                        bgcolor: 'rgba(255,255,255,0.1)',
                      }}
                    />
                    <CardContent sx={{ p: 3, position: 'relative' }}>
                      <Box
                        sx={{
                          width: 56,
                          height: 56,
                          borderRadius: 3,
                          bgcolor: 'rgba(255,255,255,0.2)',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          mb: 2,
                          backdropFilter: 'blur(10px)',
                        }}
                      >
                        {card.icon}
                      </Box>
                      <Typography variant="h6" sx={{ fontWeight: 700, mb: 0.5 }}>
                        {card.title}
                      </Typography>
                      <Typography sx={{ opacity: 0.85, fontSize: '0.875rem', mb: 2 }}>
                        {card.description}
                      </Typography>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                        <Typography sx={{ fontSize: '0.875rem', fontWeight: 600 }}>
                          Get Started
                        </Typography>
                        <ArrowForward sx={{ fontSize: 16 }} />
                      </Box>
                    </CardContent>
                  </Card>
                </motion.div>
              </Grid>
            ))}
          </Grid>
        </Box>

        {/* Recent Transactions */}
        <Box sx={{ mt: 4, mb: 4 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6, duration: 0.5 }}
            >
              <Typography variant="h6" sx={{ fontWeight: 700, color: 'var(--primary-color)' }}>
                Recent Transactions
              </Typography>
            </motion.div>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6, duration: 0.5 }}
              whileHover={{ x: 5 }}
            >
              <Box
                onClick={() => navigate('/history')}
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 0.5,
                  color: 'var(--accent-color)',
                  fontWeight: 600,
                  fontSize: '0.875rem',
                  cursor: 'pointer',
                  '&:hover': { opacity: 0.8 },
                }}
              >
                View All
                <ArrowForward sx={{ fontSize: 16 }} />
              </Box>
            </motion.div>
          </Box>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7, duration: 0.5 }}
          >
            <Card
              elevation={0}
              sx={{
                borderRadius: 4,
                background: 'rgba(255, 255, 255, 0.9)',
                backdropFilter: 'blur(20px)',
                border: '1px solid rgba(255, 255, 255, 0.5)',
                boxShadow: '0 10px 40px -10px rgba(0,0,0,0.1)',
                overflow: 'hidden',
              }}
            >
              {recentTransactions.length === 0 ? (
                <Box sx={{ p: 6, textAlign: 'center' }}>
                  <History sx={{ fontSize: 48, color: 'var(--muted-color)', mb: 2, opacity: 0.5 }} />
                  <Typography sx={{ color: 'var(--muted-color)', fontWeight: 500 }}>
                    No transactions yet
                  </Typography>
                  <Typography sx={{ color: 'var(--muted-color)', fontSize: '0.875rem', mt: 0.5 }}>
                    Start by adding money to your wallet
                  </Typography>
                </Box>
              ) : (
                <Box>
                  {recentTransactions.map((transaction, index) => (
                    <motion.div
                      key={transaction.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.8 + index * 0.1, duration: 0.4 }}
                    >
                      <Box
                        sx={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          p: 2.5,
                          borderBottom: index < recentTransactions.length - 1 ? '1px solid rgba(0,0,0,0.06)' : 'none',
                          transition: 'background 0.2s ease',
                          '&:hover': {
                            bgcolor: 'rgba(0,0,0,0.02)',
                          },
                        }}
                      >
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                          <Box
                            sx={{
                              width: 48,
                              height: 48,
                              borderRadius: 3,
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              background: transaction.type === 'add'
                                ? 'linear-gradient(135deg, rgba(34,197,94,0.15) 0%, rgba(34,197,94,0.25) 100%)'
                                : 'linear-gradient(135deg, rgba(30,58,95,0.1) 0%, rgba(30,58,95,0.2) 100%)',
                            }}
                          >
                            {transaction.type === 'add' ? (
                              <ArrowDownward sx={{ fontSize: 22, color: 'var(--success-color)' }} />
                            ) : (
                              <ArrowUpward sx={{ fontSize: 22, color: 'var(--primary-color)' }} />
                            )}
                          </Box>
                          <Box>
                            <Typography sx={{ fontWeight: 600, color: '#1a1a1a' }}>
                              {transaction.type === 'add' ? 'Money Added' : 'Money Sent'}
                            </Typography>
                            <Typography sx={{ fontSize: '0.8rem', color: 'var(--muted-color)' }}>
                              {transaction.date.toLocaleDateString('en-IN', {
                                day: 'numeric',
                                month: 'short',
                                year: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </Typography>
                          </Box>
                        </Box>
                        <Typography
                          sx={{
                            fontWeight: 700,
                            fontSize: '1.1rem',
                            color: transaction.type === 'add' ? 'var(--success-color)' : 'var(--primary-color)',
                          }}
                        >
                          {transaction.type === 'add' ? '+' : '-'}₹{transaction.amount.toLocaleString('en-IN')}
                        </Typography>
                      </Box>
                    </motion.div>
                  ))}
                </Box>
              )}
            </Card>
          </motion.div>
        </Box>
      </Container>
    </Box>
  );
};

export default Dashboard;
