import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button, Card, CardContent, Container, Box, Typography, Grid } from '@mui/material';
import {
  Security,
  Speed,
  ReceiptLong,
  ArrowForward,
  PlayCircle,
} from '@mui/icons-material';
import Navbar from '@/components/Navbar';
import { useAuth } from '@/contexts/AuthContext';

const features = [
  {
    icon: <Security sx={{ fontSize: 40 }} />,
    title: 'Secure Payments',
    description: 'Bank-grade security with end-to-end encryption for all transactions',
  },
  {
    icon: <Speed sx={{ fontSize: 40 }} />,
    title: 'Fast Transfers',
    description: 'Instant money transfers to any bank account or mobile number',
  },
  {
    icon: <ReceiptLong sx={{ fontSize: 40 }} />,
    title: 'Transaction Tracking',
    description: 'Complete history of all your transactions at your fingertips',
  },
];

const Home = () => {
  const navigate = useNavigate();
  const { user } = useAuth();

  return (
    <Box className="bg-background" sx={{ minHeight: '100vh' }}>
      <Navbar />

      {/* Hero Section */}
      <Box
        sx={{
          position: 'relative',
          overflow: 'hidden',
          minHeight: '100vh',
          display: 'flex',
          alignItems: 'center',
          background: 'linear-gradient(135deg, #0f172a 0%, #1e3a5f 50%, #0f172a 100%)',
        }}
      >
        {/* Animated Background Elements */}
        <Box sx={{ position: 'absolute', inset: 0, overflow: 'hidden' }}>
          {/* Floating Orbs */}
          {[...Array(6)].map((_, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0 }}
              animate={{
                opacity: [0.1, 0.3, 0.1],
                scale: [1, 1.2, 1],
                x: [0, 30, 0],
                y: [0, -20, 0],
              }}
              transition={{
                duration: 4 + i,
                repeat: Infinity,
                delay: i * 0.5,
              }}
              style={{
                position: 'absolute',
                width: 100 + i * 50,
                height: 100 + i * 50,
                borderRadius: '50%',
                background: i % 2 === 0 
                  ? 'radial-gradient(circle, rgba(249,115,22,0.3) 0%, transparent 70%)'
                  : 'radial-gradient(circle, rgba(30,58,95,0.5) 0%, transparent 70%)',
                left: `${10 + i * 15}%`,
                top: `${20 + (i % 3) * 25}%`,
                filter: 'blur(40px)',
              }}
            />
          ))}
          
          {/* Grid Pattern */}
          <Box
            sx={{
              position: 'absolute',
              inset: 0,
              backgroundImage: `
                linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)
              `,
              backgroundSize: '50px 50px',
            }}
          />
          
          {/* Gradient Overlay */}
          <Box
            sx={{
              position: 'absolute',
              inset: 0,
              background: 'radial-gradient(ellipse at 30% 20%, rgba(249,115,22,0.15) 0%, transparent 50%)',
            }}
          />
        </Box>

        <Container sx={{ position: 'relative', zIndex: 10, py: { xs: 8, md: 0 } }}>
          <Grid container spacing={6} alignItems="center">
            <Grid item xs={12} lg={6}>
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, ease: 'easeOut' }}
              >
                {/* Badge */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <Box
                    sx={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: 1,
                      px: 2,
                      py: 0.75,
                      borderRadius: 10,
                      bgcolor: 'rgba(249,115,22,0.15)',
                      border: '1px solid rgba(249,115,22,0.3)',
                      mb: 3,
                    }}
                  >
                    <Box
                      sx={{
                        width: 8,
                        height: 8,
                        borderRadius: '50%',
                        bgcolor: '#f97316',
                        animation: 'pulse 2s infinite',
                      }}
                    />
                    <Typography sx={{ color: '#f97316', fontSize: '0.875rem', fontWeight: 500 }}>
                      Secure & Fast Payments
                    </Typography>
                  </Box>
                </motion.div>

                {/* Main Heading */}
                <Typography
                  variant="h1"
                  sx={{
                    fontWeight: 800,
                    fontSize: { xs: '2.5rem', md: '3.5rem', lg: '4rem' },
                    lineHeight: 1.1,
                    mb: 3,
                    color: 'white',
                  }}
                >
                  The Future of
                  <br />
                  <Box
                    component="span"
                    sx={{
                      background: 'linear-gradient(135deg, #f97316 0%, #fb923c 50%, #fbbf24 100%)',
                      WebkitBackgroundClip: 'text',
                      WebkitTextFillColor: 'transparent',
                      backgroundClip: 'text',
                    }}
                  >
                    Digital Payments
                  </Box>
                </Typography>

                <Typography
                  sx={{
                    fontSize: { xs: '1rem', md: '1.25rem' },
                    color: 'rgba(255,255,255,0.7)',
                    mb: 4,
                    maxWidth: 480,
                    lineHeight: 1.7,
                  }}
                >
                  Experience lightning-fast transfers, bank-grade security, and seamless 
                  transaction tracking — all in one intuitive platform.
                </Typography>

                {/* CTA Buttons */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                >
                  <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
                    <Button
                      variant="contained"
                      size="large"
                      onClick={() => navigate('/dashboard')}
                      endIcon={<ArrowForward />}
                      sx={{
                        py: 1.75,
                        px: 4,
                        borderRadius: 3,
                        background: 'linear-gradient(135deg, #f97316 0%, #ea580c 100%)',
                        fontSize: '1.1rem',
                        fontWeight: 600,
                        textTransform: 'none',
                        boxShadow: '0 10px 40px rgba(249,115,22,0.4)',
                        '&:hover': {
                          background: 'linear-gradient(135deg, #ea580c 0%, #c2410c 100%)',
                          transform: 'translateY(-3px)',
                          boxShadow: '0 15px 50px rgba(249,115,22,0.5)',
                        },
                        transition: 'all 0.3s ease',
                      }}
                    >
                      Get Started
                    </Button>
                    <Button
                      variant="outlined"
                      size="large"
                      startIcon={<PlayCircle />}
                      sx={{
                        py: 1.75,
                        px: 4,
                        borderRadius: 3,
                        borderColor: 'rgba(255,255,255,0.3)',
                        color: 'white',
                        fontSize: '1.1rem',
                        fontWeight: 600,
                        textTransform: 'none',
                        backdropFilter: 'blur(10px)',
                        '&:hover': {
                          borderColor: 'rgba(255,255,255,0.5)',
                          bgcolor: 'rgba(255,255,255,0.1)',
                        },
                      }}
                    >
                      Watch Demo
                    </Button>
                  </Box>
                </motion.div>

                {/* Stats */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.6 }}
                >
                  <Box sx={{ display: 'flex', gap: 4, mt: 5, flexWrap: 'wrap' }}>
                    {[
                      { value: '10K+', label: 'Active Users' },
                      { value: '₹5Cr+', label: 'Transactions' },
                      { value: '99.9%', label: 'Uptime' },
                    ].map((stat, index) => (
                      <Box key={index}>
                        <Typography
                          sx={{
                            fontSize: '1.75rem',
                            fontWeight: 700,
                            color: 'white',
                          }}
                        >
                          {stat.value}
                        </Typography>
                        <Typography sx={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.875rem' }}>
                          {stat.label}
                        </Typography>
                      </Box>
                    ))}
                  </Box>
                </motion.div>
              </motion.div>
            </Grid>

            <Grid item xs={12} lg={6}>
              <motion.div
                initial={{ opacity: 0, scale: 0.8, rotateY: -15 }}
                animate={{ opacity: 1, scale: 1, rotateY: 0 }}
                transition={{ delay: 0.3, duration: 0.8, ease: 'easeOut' }}
              >
                {/* Floating Card Stack */}
                <Box sx={{ position: 'relative', height: { xs: 350, md: 450 } }}>
                  {/* Background Card */}
                  <motion.div
                    animate={{ y: [0, -10, 0] }}
                    transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                    style={{
                      position: 'absolute',
                      top: 40,
                      left: 40,
                      right: 0,
                      bottom: 0,
                    }}
                  >
                    <Card
                      elevation={0}
                      sx={{
                        height: '100%',
                        borderRadius: 4,
                        background: 'linear-gradient(135deg, rgba(30,58,95,0.6) 0%, rgba(15,23,42,0.6) 100%)',
                        backdropFilter: 'blur(20px)',
                        border: '1px solid rgba(255,255,255,0.1)',
                      }}
                    />
                  </motion.div>

                  {/* Main Card */}
                  <motion.div
                    animate={{ y: [0, -15, 0] }}
                    transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut', delay: 0.5 }}
                    style={{ position: 'absolute', inset: 0, right: 40, bottom: 40 }}
                  >
                    <Card
                      elevation={0}
                      sx={{
                        height: '100%',
                        borderRadius: 4,
                        background: 'linear-gradient(135deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0.05) 100%)',
                        backdropFilter: 'blur(20px)',
                        border: '1px solid rgba(255,255,255,0.2)',
                        p: 3,
                        display: 'flex',
                        flexDirection: 'column',
                      }}
                    >
                      {/* Card Header */}
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                          <Box
                            sx={{
                              width: 40,
                              height: 40,
                              borderRadius: 2,
                              background: 'linear-gradient(135deg, #f97316, #fbbf24)',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                            }}
                          >
                            <Security sx={{ color: 'white', fontSize: 20 }} />
                          </Box>
                          <Typography sx={{ color: 'white', fontWeight: 600 }}>PaytmClone</Typography>
                        </Box>
                        <Box sx={{ display: 'flex', gap: 0.5 }}>
                          {[1, 2, 3].map((i) => (
                            <Box
                              key={i}
                              sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: 'rgba(255,255,255,0.3)' }}
                            />
                          ))}
                        </Box>
                      </Box>

                      {/* Balance Display */}
                      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                        <Typography sx={{ color: 'rgba(255,255,255,0.6)', fontSize: '0.875rem', mb: 1 }}>
                          Total Balance
                        </Typography>
                        <Typography
                          sx={{
                            fontSize: { xs: '2rem', md: '2.5rem' },
                            fontWeight: 700,
                            color: 'white',
                            mb: 3,
                          }}
                        >
                          ₹24,500.00
                        </Typography>

                        {/* Quick Actions */}
                        <Box sx={{ display: 'flex', gap: 2 }}>
                          {[
                            { icon: <Speed sx={{ fontSize: 18 }} />, label: 'Send' },
                            { icon: <ReceiptLong sx={{ fontSize: 18 }} />, label: 'History' },
                          ].map((action, idx) => (
                            <Box
                              key={idx}
                              sx={{
                                flex: 1,
                                py: 1.5,
                                borderRadius: 2,
                                bgcolor: 'rgba(255,255,255,0.1)',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                gap: 1,
                                cursor: 'pointer',
                                transition: 'all 0.2s',
                                '&:hover': { bgcolor: 'rgba(255,255,255,0.15)' },
                              }}
                            >
                              <Box sx={{ color: '#f97316' }}>{action.icon}</Box>
                              <Typography sx={{ color: 'white', fontSize: '0.875rem' }}>{action.label}</Typography>
                            </Box>
                          ))}
                        </Box>
                      </Box>

                      {/* Recent Transaction */}
                      <Box
                        sx={{
                          mt: 3,
                          p: 2,
                          borderRadius: 2,
                          bgcolor: 'rgba(249,115,22,0.1)',
                          border: '1px solid rgba(249,115,22,0.2)',
                        }}
                      >
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <Box>
                            <Typography sx={{ color: 'rgba(255,255,255,0.6)', fontSize: '0.75rem' }}>
                              Last Transaction
                            </Typography>
                            <Typography sx={{ color: 'white', fontWeight: 500 }}>₹2,500 to John</Typography>
                          </Box>
                          <Box
                            sx={{
                              px: 1.5,
                              py: 0.5,
                              borderRadius: 1,
                              bgcolor: 'rgba(34,197,94,0.2)',
                              color: '#22c55e',
                              fontSize: '0.75rem',
                              fontWeight: 500,
                            }}
                          >
                            Success
                          </Box>
                        </Box>
                      </Box>
                    </Card>
                  </motion.div>

                  {/* Floating Elements */}
                  <motion.div
                    animate={{ y: [0, -20, 0], rotate: [0, 5, 0] }}
                    transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
                    style={{ position: 'absolute', top: -20, right: 20 }}
                  >
                    <Box
                      sx={{
                        width: 60,
                        height: 60,
                        borderRadius: 3,
                        background: 'linear-gradient(135deg, #f97316, #fbbf24)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        boxShadow: '0 10px 30px rgba(249,115,22,0.4)',
                      }}
                    >
                      <Speed sx={{ color: 'white', fontSize: 28 }} />
                    </Box>
                  </motion.div>

                  <motion.div
                    animate={{ y: [0, 15, 0], rotate: [0, -5, 0] }}
                    transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
                    style={{ position: 'absolute', bottom: 60, left: -20 }}
                  >
                    <Box
                      sx={{
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        background: 'linear-gradient(135deg, #1e3a5f, #0f172a)',
                        border: '2px solid rgba(255,255,255,0.2)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <Security sx={{ color: '#f97316', fontSize: 24 }} />
                    </Box>
                  </motion.div>
                </Box>
              </motion.div>
            </Grid>
          </Grid>
        </Container>

        {/* Bottom Wave */}
        <Box sx={{ position: 'absolute', bottom: -2, left: 0, right: 0 }}>
          <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" style={{ width: '100%', height: 80 }}>
            <path
              d="M0 120L48 108C96 96 192 72 288 60C384 48 480 48 576 54C672 60 768 72 864 78C960 84 1056 84 1152 78C1248 72 1344 60 1392 54L1440 48V120H1392C1344 120 1248 120 1152 120C1056 120 960 120 864 120C768 120 672 120 576 120C480 120 384 120 288 120C192 120 96 120 48 120H0Z"
              fill="var(--background-color)"
            />
          </svg>
        </Box>
      </Box>

      {/* Video Explanation Section */}
      <Box sx={{ py: 8, px: 2 }}>
        <Container>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <Box sx={{ textAlign: 'center', maxWidth: 800, mx: 'auto' }}>
              <Typography variant="h4" sx={{ fontWeight: 700, mb: 2 }}>
                About This Project
              </Typography>
              <Typography sx={{ color: 'var(--muted-color)', mb: 4 }}>
                This video explains my Paytm Clone project, its features, and how users
                can add money, send money, and track transactions seamlessly.
              </Typography>
              
              <Card elevation={0} sx={{ borderRadius: 4, overflow: 'hidden', boxShadow: 'var(--shadow-card)' }}>
                <CardContent sx={{ p: 0 }}>
                  <Box
                    sx={{
                      aspectRatio: '16/9',
                      bgcolor: '#f1f5f9',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      position: 'relative',
                    }}
                  >
                    <Box
                      sx={{
                        position: 'absolute',
                        inset: 0,
                        background: 'linear-gradient(135deg, rgba(30,58,95,0.05), rgba(249,115,22,0.05))',
                      }}
                    />
                    <Box sx={{ textAlign: 'center', zIndex: 10 }}>
                      <motion.div whileHover={{ scale: 1.1 }} style={{ cursor: 'pointer', display: 'inline-block' }}>
                        <PlayCircle sx={{ fontSize: 80, color: 'var(--primary-color)' }} />
                      </motion.div>
                      <Typography sx={{ color: 'var(--muted-color)', mt: 2 }}>
                        AI-generated video placeholder
                      </Typography>
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            </Box>
          </motion.div>
        </Container>
      </Box>

      {/* Features Section */}
      <Box sx={{ py: 8, px: 2, bgcolor: 'rgba(241,245,249,0.5)' }}>
        <Container>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <Typography variant="h4" sx={{ fontWeight: 700, textAlign: 'center', mb: 6 }}>
              Why Choose PaytmClone?
            </Typography>
          </motion.div>

          <Grid container spacing={4}>
            {features.map((feature, index) => (
              <Grid item xs={12} md={4} key={index}>
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card
                    elevation={0}
                    className="action-card"
                    sx={{ height: '100%', borderRadius: 4 }}
                  >
                    <CardContent sx={{ p: 4, textAlign: 'center' }}>
                      <motion.div whileHover={{ scale: 1.1, rotate: 5 }}>
                        <Box
                          className="paytm-gradient"
                          sx={{
                            width: 64,
                            height: 64,
                            borderRadius: 4,
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            mx: 'auto',
                            mb: 2,
                            color: 'white',
                          }}
                        >
                          {feature.icon}
                        </Box>
                      </motion.div>
                      <Typography variant="h6" sx={{ fontWeight: 600, mb: 1 }}>
                        {feature.title}
                      </Typography>
                      <Typography sx={{ color: 'var(--muted-color)' }}>
                        {feature.description}
                      </Typography>
                    </CardContent>
                  </Card>
                </motion.div>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      {/* CTA Section */}
      <Box sx={{ py: 10, px: 2 }}>
        <Container>
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
          >
            <Box
              className="wallet-gradient"
              sx={{
                borderRadius: 6,
                p: { xs: 4, md: 6 },
                textAlign: 'center',
                color: 'white',
                position: 'relative',
                overflow: 'hidden',
              }}
            >
              <Box
                sx={{
                  position: 'absolute',
                  inset: 0,
                  opacity: 0.5,
                  backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.05'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")",
                }}
              />
              
              <Typography
                variant="h4"
                sx={{ fontWeight: 700, mb: 2, position: 'relative', zIndex: 10 }}
              >
                Ready to Get Started?
              </Typography>
              <Typography
                sx={{
                  color: 'rgba(255,255,255,0.8)',
                  fontSize: '1.125rem',
                  mb: 4,
                  maxWidth: 600,
                  mx: 'auto',
                  position: 'relative',
                  zIndex: 10,
                }}
              >
                Access your dashboard now to add money, send payments, and manage
                all your transactions with ease.
              </Typography>
              <motion.div whileHover={{ scale: 1.05 }} style={{ position: 'relative', zIndex: 10 }}>
                <Button
                  variant="contained"
                  size="large"
                  onClick={() => navigate('/dashboard')}
                  endIcon={<ArrowForward />}
                  sx={{
                    py: 1.5,
                    px: 5,
                    borderRadius: 2,
                    bgcolor: 'white',
                    color: 'var(--primary-color)',
                    fontSize: '1.1rem',
                    fontWeight: 600,
                    '&:hover': {
                      bgcolor: 'white',
                    },
                  }}
                >
                  Go to Dashboard
                </Button>
              </motion.div>
            </Box>
          </motion.div>
        </Container>
      </Box>

      {/* Footer */}
      <Box sx={{ py: 4, px: 2, borderTop: '1px solid var(--border-color)' }}>
        <Container>
          <Typography sx={{ textAlign: 'center', color: 'var(--muted-color)' }}>
            © 2024 PaytmClone. A demo project for learning purposes.
          </Typography>
        </Container>
      </Box>
    </Box>
  );
};

export default Home;
