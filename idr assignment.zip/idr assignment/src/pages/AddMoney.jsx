import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Card,
  CardContent,
  TextField,
  Button,
  InputAdornment,
  Snackbar,
  Alert,
  Chip,
  Container,
  Box,
  Typography,
} from '@mui/material';
import { AddCard, CurrencyRupee, CheckCircle } from '@mui/icons-material';
import Navbar from '@/components/Navbar';
import { useWallet } from '@/contexts/WalletContext';

const quickAmounts = [500, 1000, 2000, 5000];

const AddMoney = () => {
  const [amount, setAmount] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [showSnackbar, setShowSnackbar] = useState(false);
  const { balance, addMoney } = useWallet();

  const handleAddMoney = async () => {
    const numAmount = parseInt(amount);
    if (!numAmount || numAmount <= 0) return;

    setLoading(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500));

    addMoney(numAmount);
    setSuccess(true);
    setShowSnackbar(true);
    setLoading(false);
    setAmount('');

    setTimeout(() => setSuccess(false), 2000);
  };

  return (
    <Box className="bg-background" sx={{ minHeight: '100vh' }}>
      <Navbar />

      <Container sx={{ py: 4 }}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Box sx={{ maxWidth: 480, mx: 'auto' }}>
            {/* Header */}
            <Box sx={{ textAlign: 'center', mb: 4 }}>
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: 'spring', stiffness: 200 }}
              >
                <Box
                  className="paytm-gradient"
                  sx={{
                    width: 64,
                    height: 64,
                    borderRadius: 4,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    mx: 'auto',
                    mb: 2,
                  }}
                >
                  <AddCard sx={{ fontSize: 32, color: 'white' }} />
                </Box>
              </motion.div>
              <Typography variant="h5" sx={{ fontWeight: 700 }}>
                Add Money
              </Typography>
              <Typography sx={{ color: 'var(--muted-color)' }}>
                Add funds to your wallet
              </Typography>
            </Box>

            {/* Balance Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <Card
                elevation={0}
                sx={{
                  borderRadius: 3,
                  mb: 3,
                  background: 'var(--gradient-card)',
                  color: 'white',
                }}
              >
                <CardContent sx={{ py: 3, textAlign: 'center' }}>
                  <Typography sx={{ color: 'rgba(255,255,255,0.7)', fontSize: '0.875rem', mb: 0.5 }}>
                    Current Balance
                  </Typography>
                  <Typography variant="h4" sx={{ fontWeight: 700 }}>
                    ₹{balance.toLocaleString('en-IN')}
                  </Typography>
                </CardContent>
              </Card>
            </motion.div>

            {/* Add Money Form */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Card elevation={0} sx={{ borderRadius: 4, boxShadow: 'var(--shadow-card)' }}>
                <CardContent sx={{ p: 4 }}>
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
                    {/* Amount Input */}
                    <TextField
                      fullWidth
                      label="Enter Amount"
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="0"
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <CurrencyRupee color="action" />
                          </InputAdornment>
                        ),
                        sx: { fontSize: '1.25rem' },
                      }}
                    />

                    {/* Quick Amount Chips */}
                    <Box>
                      <Typography sx={{ fontSize: '0.875rem', color: 'var(--muted-color)', mb: 1.5 }}>
                        Quick Select
                      </Typography>
                      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                        {quickAmounts.map((quickAmount) => (
                          <motion.div
                            key={quickAmount}
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                          >
                            <Chip
                              label={`₹${quickAmount}`}
                              onClick={() => setAmount(quickAmount.toString())}
                              variant={amount === quickAmount.toString() ? 'filled' : 'outlined'}
                              color={amount === quickAmount.toString() ? 'primary' : 'default'}
                              sx={{ px: 1, fontWeight: 500 }}
                            />
                          </motion.div>
                        ))}
                      </Box>
                    </Box>

                    {/* Add Money Button */}
                    <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                      <Button
                        fullWidth
                        variant="contained"
                        size="large"
                        onClick={handleAddMoney}
                        disabled={!amount || parseInt(amount) <= 0 || loading}
                        startIcon={success ? <CheckCircle /> : loading ? null : <AddCard />}
                        sx={{
                          py: 1.5,
                          borderRadius: 2,
                          background: success ? 'var(--success-color)' : 'var(--gradient-primary)',
                          fontSize: '1rem',
                          fontWeight: 600,
                          boxShadow: success
                            ? '0 4px 15px rgba(34, 197, 94, 0.3)'
                            : '0 4px 15px rgba(30, 58, 95, 0.3)',
                          '&:hover': {
                            boxShadow: success
                              ? '0 6px 20px rgba(34, 197, 94, 0.4)'
                              : '0 6px 20px rgba(30, 58, 95, 0.4)',
                          },
                          '&:disabled': {
                            background: '#e2e8f0',
                            color: 'var(--muted-color)',
                          },
                        }}
                      >
                        {loading ? 'Processing...' : success ? 'Money Added!' : 'Add Money to Wallet'}
                      </Button>
                    </motion.div>
                  </Box>
                </CardContent>
              </Card>
            </motion.div>

            {/* Info Text */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
            >
              <Typography
                sx={{
                  textAlign: 'center',
                  fontSize: '0.875rem',
                  color: 'var(--muted-color)',
                  mt: 3,
                }}
              >
                Money will be added instantly to your wallet
              </Typography>
            </motion.div>
          </Box>
        </motion.div>
      </Container>

      {/* Success Snackbar */}
      <Snackbar
        open={showSnackbar}
        autoHideDuration={4000}
        onClose={() => setShowSnackbar(false)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert
          onClose={() => setShowSnackbar(false)}
          severity="success"
          variant="filled"
          sx={{ borderRadius: 2, fontWeight: 500 }}
        >
          Money added successfully to your wallet!
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default AddMoney;
