import { BrowserRouter, Routes, Route } from "react-router-dom";
import IDRHome from "@/pages/IDRHome";

const App = () => (
  <BrowserRouter>
    <Routes>
      <Route path="/" element={<IDRHome />} />
      <Route path="*" element={<IDRHome />} />
    </Routes>
  </BrowserRouter>
);

export default App;
