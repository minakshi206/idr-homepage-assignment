import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  AppBar,
  Toolbar,
  IconButton,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Avatar,
  Menu,
  MenuItem,
  useMediaQuery,
  useTheme,
  Box,
  Typography,
  Container,
} from '@mui/material';
import {
  Menu as MenuIcon,
  Home,
  Dashboard,
  AddCard,
  Send,
  History,
  Logout,
  AccountBalanceWallet,
} from '@mui/icons-material';
import { useAuth } from '@/contexts/AuthContext';

const Navbar = () => {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));

  const menuItems = [
    { text: 'Home', icon: <Home />, path: '/home' },
    { text: 'Dashboard', icon: <Dashboard />, path: '/dashboard' },
    { text: 'Add Money', icon: <AddCard />, path: '/add-money' },
    { text: 'Send Money', icon: <Send />, path: '/send-money' },
    { text: 'History', icon: <History />, path: '/history' },
  ];

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const handleProfileClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleProfileClose = () => {
    setAnchorEl(null);
  };

  return (
    <>
      <AppBar
        position="sticky"
        elevation={0}
        sx={{
          background: 'rgba(255, 255, 255, 0.95)',
          backdropFilter: 'blur(10px)',
          borderBottom: '1px solid var(--border-color)',
        }}
      >
        <Container>
          <Toolbar sx={{ px: { xs: 0 } }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Box
                className="paytm-gradient"
                sx={{
                  width: 40,
                  height: 40,
                  borderRadius: 3,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <AccountBalanceWallet sx={{ color: 'white', fontSize: 24 }} />
              </Box>
              <Typography
                sx={{
                  fontSize: '1.25rem',
                  fontWeight: 700,
                  color: 'var(--primary-color)',
                }}
              >
                PaytmClone
              </Typography>
            </Box>

            {!isMobile && (
              <Box
                component="nav"
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 0.5,
                  mx: 'auto',
                }}
              >
                {menuItems.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    style={{ textDecoration: 'none' }}
                  >
                    <Box
                      sx={{
                        px: 2,
                        py: 1,
                        borderRadius: 2,
                        fontWeight: 500,
                        fontSize: '0.875rem',
                        transition: 'all 0.2s',
                        bgcolor:
                          location.pathname === item.path
                            ? '#f1f5f9'
                            : 'transparent',
                        color:
                          location.pathname === item.path
                            ? 'var(--primary-color)'
                            : 'var(--muted-color)',
                        '&:hover': {
                          bgcolor: '#f1f5f9',
                          color: 'var(--foreground-color)',
                        },
                      }}
                    >
                      {item.text}
                    </Box>
                  </Link>
                ))}
              </Box>
            )}

            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, ml: 'auto' }}>
              <IconButton onClick={handleProfileClick}>
                <Avatar
                  sx={{
                    bgcolor: 'var(--primary-color)',
                    width: 40,
                    height: 40,
                  }}
                >
                  {user?.name?.charAt(0) || 'U'}
                </Avatar>
              </IconButton>

              {isMobile && (
                <IconButton
                  onClick={() => setDrawerOpen(true)}
                  sx={{ color: 'var(--foreground-color)' }}
                >
                  <MenuIcon />
                </IconButton>
              )}
            </Box>

            <Menu
              anchorEl={anchorEl}
              open={Boolean(anchorEl)}
              onClose={handleProfileClose}
              PaperProps={{
                sx: {
                  mt: 1,
                  borderRadius: 2,
                  boxShadow: 'var(--shadow-lg)',
                },
              }}
            >
              <MenuItem disabled>
                <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                  <Typography sx={{ fontWeight: 500 }}>{user?.name}</Typography>
                  <Typography sx={{ fontSize: '0.875rem', color: 'var(--muted-color)' }}>
                    {user?.email}
                  </Typography>
                </Box>
              </MenuItem>
              <MenuItem onClick={handleLogout} sx={{ color: 'var(--destructive-color)' }}>
                <Logout sx={{ mr: 1 }} /> Logout
              </MenuItem>
            </Menu>
          </Toolbar>
        </Container>
      </AppBar>

      <Drawer
        anchor="right"
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        PaperProps={{
          sx: {
            width: 280,
            borderTopLeftRadius: 16,
            borderBottomLeftRadius: 16,
          },
        }}
      >
        <Box sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
            <Avatar sx={{ bgcolor: 'var(--primary-color)', width: 48, height: 48 }}>
              {user?.name?.charAt(0) || 'U'}
            </Avatar>
            <Box>
              <Typography sx={{ fontWeight: 600 }}>{user?.name}</Typography>
              <Typography sx={{ fontSize: '0.875rem', color: 'var(--muted-color)' }}>
                {user?.phone}
              </Typography>
            </Box>
          </Box>

          <List>
            <AnimatePresence>
              {menuItems.map((item, index) => (
                <motion.div
                  key={item.path}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <ListItem
                    component={Link}
                    to={item.path}
                    onClick={() => setDrawerOpen(false)}
                    sx={{
                      borderRadius: 2,
                      mb: 0.5,
                      bgcolor:
                        location.pathname === item.path ? '#f1f5f9' : 'transparent',
                      '&:hover': {
                        bgcolor: '#f1f5f9',
                      },
                      textDecoration: 'none',
                      color: 'inherit',
                    }}
                  >
                    <ListItemIcon
                      sx={{
                        color:
                          location.pathname === item.path
                            ? 'var(--primary-color)'
                            : 'inherit',
                      }}
                    >
                      {item.icon}
                    </ListItemIcon>
                    <ListItemText
                      primary={item.text}
                      sx={{
                        '& .MuiTypography-root': {
                          fontWeight: location.pathname === item.path ? 600 : 400,
                          color:
                            location.pathname === item.path
                              ? 'var(--primary-color)'
                              : 'inherit',
                        },
                      }}
                    />
                  </ListItem>
                </motion.div>
              ))}
            </AnimatePresence>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: menuItems.length * 0.1 }}
            >
              <ListItem
                onClick={handleLogout}
                sx={{
                  borderRadius: 2,
                  mt: 2,
                  cursor: 'pointer',
                  color: 'var(--destructive-color)',
                  '&:hover': {
                    bgcolor: 'rgba(239, 68, 68, 0.1)',
                  },
                }}
              >
                <ListItemIcon sx={{ color: 'inherit' }}>
                  <Logout />
                </ListItemIcon>
                <ListItemText primary="Logout" />
              </ListItem>
            </motion.div>
          </List>
        </Box>
      </Drawer>
    </>
  );
};

export default Navbar;
